<?php
        function salam($nama="nurul"){

            echo "Selamat Datang $nama";
        
        }
        salam();
    ?>